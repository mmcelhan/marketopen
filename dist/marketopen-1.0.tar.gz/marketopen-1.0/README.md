# marketopen
Package that returns if the stock market is open given a date

![image of usage](https://github.com/mmcelhan/marketopen/blob/main/image/market_open_usage.png)

Install from github with the following command (Windows):

pip install git+https://github.com/mmcelhan/marketopen.git#egg=marketopen
